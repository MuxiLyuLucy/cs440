How to install extension: 
  1. cd proj4
  2. Run npm run watch
  3. Open chrome://extensions
  4. Check the Developer mode checkbox
  5. Click on the Load unpacked extension button
  6. Select the folder proj4/build

How it works:
  1. open chrome browser
  2. have a tab with changed content
  3. move to other tab
  4. move back and you will see the color overlay

---

This project was bootstrapped with [Chrome Extension CLI](https://github.com/dutiyesh/chrome-extension-cli)