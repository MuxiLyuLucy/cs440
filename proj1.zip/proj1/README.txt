Citations:

https://prezi.com/whocqwn3qhjt/ai-player-for-five-in-a-row/