/* This is a completely awesome invisible gadget */
function call() {
    console.log("I'm a gadget!");
}
