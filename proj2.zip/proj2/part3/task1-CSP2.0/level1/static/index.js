// set onfocus for query
document.getElementById('query').onfocus = function() {
    this.value = '';
}